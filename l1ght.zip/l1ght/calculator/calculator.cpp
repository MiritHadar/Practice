/******************************************************************************/
/* author: 		Mirit Hadar											  	      */
/* version: 	Final			  		                                      */
/* Last update: 							                                  */
/******************************************************************************/

// #include <sstream>          // stringstream
#include <iostream>            // cout
#include <memory>              // shared_ptr
#include "calculator.hpp"      // header file

namespace l1ght
{

using namespace std;

vector<double> Calculator::Calculate(const char fileName_[])
{
    vector<string> vecOfStrings = Parser::Parse(fileName_);
    
    for (vector<string>::iterator it = vecOfStrings.begin(); it != vecOfStrings.end(); ++it)
    {
        cout << *it << endl;
        SortBetweenStacks(*it);
    }
}

void Calculator::SortBetweenStacks(string str_)
{

}

void Calculator::Execute()
{
    
}

}//namespace l1ght
