
template<class T>
T *Deadbeef()
{
    return reinterpret_cast<T*>(0xDEADBEEF);
}